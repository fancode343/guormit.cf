<?php 
$con = mysqli_connect('sql212.freewebhosting.com.bd', 'ieeos_31116650', 'nqmustwl@pussport.com', 'ieeos_31116650_Discord_DB');
?>
